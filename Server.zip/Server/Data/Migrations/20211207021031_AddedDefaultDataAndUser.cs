﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CarRentalManagement1.Server.Data.Migrations
{
    public partial class AddedDefaultDataAndUser : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Colours",
                columns: new[] { "Id", "CreatedBy", "DateCreated", "DateUpdated", "Name", "UpdatedBy" },
                values: new object[,]
                {
                    { 1, "System", new DateTime(2021, 12, 7, 10, 10, 31, 340, DateTimeKind.Local).AddTicks(8455), new DateTime(2021, 12, 7, 10, 10, 31, 341, DateTimeKind.Local).AddTicks(7919), "Black", "System" },
                    { 2, "System", new DateTime(2021, 12, 7, 10, 10, 31, 341, DateTimeKind.Local).AddTicks(8953), new DateTime(2021, 12, 7, 10, 10, 31, 341, DateTimeKind.Local).AddTicks(8959), "Blue", "System" }
                });

            migrationBuilder.InsertData(
                table: "Makes",
                columns: new[] { "Id", "CreatedBy", "DateCreated", "DateUpdated", "Name", "UpdatedBy" },
                values: new object[,]
                {
                    { 1, "System", new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(1526), new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(1535), "BMW", "System" },
                    { 2, "System", new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(1539), new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(1540), "Toyota", "System" }
                });

            migrationBuilder.InsertData(
                table: "Models",
                columns: new[] { "Id", "CreatedBy", "DateCreated", "DateUpdated", "Name", "UpdatedBy" },
                values: new object[,]
                {
                    { 1, "System", new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(5383), new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(5390), "3 Series", "System" },
                    { 2, "System", new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(5394), new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(5395), "X5", "System" },
                    { 3, "System", new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(5397), new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(5398), "Prius", "System" },
                    { 4, "System", new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(5399), new DateTime(2021, 12, 7, 10, 10, 31, 343, DateTimeKind.Local).AddTicks(5400), "Rav4", "System" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Colours",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Colours",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Makes",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Makes",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Models",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Models",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Models",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Models",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
